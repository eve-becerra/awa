package com.cbs.banking.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cbs.banking.model.Project;
import com.cbs.banking.model.Vendor;
import com.cbs.banking.repository.ProjectRepository;

@RestController
public class ProjectController {
	@Autowired
	private ProjectRepository projectRepository;

	@RequestMapping("/project/add")
	public Project addProject(@RequestBody Project project) {
		return projectRepository.save(project);
	}

	@PostMapping("/project")
	public Project postProject(@RequestBody Project project) {
		return projectRepository.save(project);
	}

	@GetMapping("/project")
	public List<Project> getAllProjects() {
		return projectRepository.findAll();
	}



}