package com.cbs.banking.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cbs.banking.model.Order;
import com.cbs.banking.model.Project;
import com.cbs.banking.repository.OrderRepository;
import com.cbs.banking.repository.ProjectRepository;

@RestController
public class ProjectController {
	@Autowired
	private ProjectRepository projectRepository;
	@Autowired
	private OrderRepository orderRepository;

	@RequestMapping("/project/add")
	public Project addProject(@RequestBody Project project) {
		return projectRepository.save(project);
	}

	@PostMapping("/project")
	public Project postProject(@RequestBody Project project) {
		return projectRepository.save(project);
	}

	@GetMapping("/project")
	public List<Project> getAllProjects() {
		return projectRepository.findAll();
	}

	@GetMapping("/project/stats")
	public Map<String, Double> projectStats() {
		// call the api to fetch completed orders
		Map<String, Double> map = new HashMap<>();
		
		List<Project> list = projectRepository.findAll();
		Double totalProjects = (double) list.size();// number of projects
		Double totalAmount = list.stream().mapToDouble(Project::getAmountReceivable).sum();// total amount 

		
		List<Order> list2 = orderRepository.fetchOrderByStatus("PENDING");
		Double totalDue = list2.stream().mapToDouble(Order::getAmount).sum();// total Due
		
		List<Order> list3 = orderRepository.fetchOrderByStatus("COMPLETED");
		Double totalExpense = list3.stream().mapToDouble(Order::getAmount).sum();// total expense

		
		map.put("Total Projects", totalProjects);
		map.put("Total Amount", totalAmount);
		map.put("Total Expense", totalExpense);
		map.put("Total Due", totalDue);

		return map;
	}

}