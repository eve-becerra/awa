package com.cbs.banking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankSystemBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
