package com.cbsbankui.model;

public class OrderDto {
	int totalOrders;
	int completedOrders;
	int pendingOrders;
	
	public int getTotalOrders() {
		return totalOrders;
	}
	public void setTotalOrders(int totalOrders) {
		this.totalOrders = totalOrders;
	}
	public int getCompletedOrders() {
		return completedOrders;
	}
	public void setCompletedOrders(int completedOrders) {
		this.completedOrders = completedOrders;
	}
	public int getPendingOrders() {
		return pendingOrders;
	}
	public void setPendingOrders(int pendingOrders) {
		this.pendingOrders = pendingOrders;
	}
	
	

}
